int main(int argc, char const *argv[]) {
  Stack *stack = stack_ini()
  return 0;
}
