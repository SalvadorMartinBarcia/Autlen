#ifndef MINIMIZA_H
#define MINIMIZA_H

#include <stdio.h>
#include "afnd.h"
#include "transforma.h"

AFND* AFNDMinimiza(AFND * afnd);

#endif